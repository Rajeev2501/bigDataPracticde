package com.kafka.utils;


import org.apache.kafka.clients.admin.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class TopicCreator
{
    public static void main(String[] args) throws Exception {
        Properties config = new Properties();
        config.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");

        AdminClient admin = AdminClient.create(config);

        Map<String, String> configs = new HashMap<>();
        int partitions = 1;
        int replication = 1;
        System.out.println("Creating the kafka topic through the api");

        try{
            admin.createTopics(Collections.singleton(new NewTopic("topic1", partitions, (short) replication).configs(configs)));
            System.out.println("Cheers!! Topic topic1 is created successfully!!!! Terminating the application");
            System.exit(1);
        }
        catch (Exception e){
            System.out.println("Exception encountered while topic creation ");
            System.out.println(e);
        }


        System.out.println();
    }
}
